# get data
item replace block -30000000 0 0 container.0 from entity @s enderchest.12

# set slot
data modify storage summit:temp balloon.slot set value "enderchest.12"

# do checks and process
function summit.balloon:inventory/process
