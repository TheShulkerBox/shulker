# get data
item replace block -30000000 0 0 container.0 from entity @s hotbar.1

# set slot
data modify storage summit:temp balloon.slot set value "hotbar.1"

# do checks and process
function summit.balloon:inventory/process
