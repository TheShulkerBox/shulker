
# allow summit to override
data modify storage summit.battlegrounds:temp summit_check set value {booth_id: "official_summit"}

# check if booth is valid
$execute store success score #booth_matches summit.battlegrounds run data get storage summit.battlegrounds:database session{booth_id:"$(booth_id)"}
$execute unless score #booth_matches summit.battlegrounds matches 1 if data storage summit.battlegrounds:temp summit_check{booth_id:"$(booth_id)"} run scoreboard players set #booth_matches summit.battlegrounds 1
execute unless score #booth_matches summit.battlegrounds matches 1 run return -1

# place structure
$place template $(structure) -118 60 97 none none 1 0 strict

# prevent players from getting crushed
execute as @a[tag=summit.battlegrounds.player] at @s unless block ~ ~ ~ #air unless block ~ ~1 ~ #air run function summit.battlegrounds:player/teleport/random

return 1
