
function summit.battlegrounds:initialize
