
# reset timers
function summit.battlegrounds:battleground/reset_timers

# function tag
function #summit.battlegrounds:api/booth_inactive
execute as @a[tag=summit.battlegrounds.player] run function #summit.battlegrounds:api/player_leave

# reset structure
function summit.battlegrounds:api/set_structure {booth_id: "official_summit", structure: "summit.battlegrounds:default"}

# move to next booth in queue
function summit.battlegrounds:booth_queue/advance_queue

# reset players and give new kit
execute as @a[tag=summit.battlegrounds.player] run function summit.battlegrounds:player/action/clear_items
function summit.battlegrounds:kit_selection/unassign_kit/all
execute as @a[tag=summit.battlegrounds.player] run function summit.battlegrounds:player/action/give_kit

# function tag
execute as @a[tag=summit.battlegrounds.player] run function #summit.battlegrounds:api/player_enter
