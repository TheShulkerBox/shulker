
# get player data for macro
function summit.battlegrounds:utility/get_head
function summit.battlegrounds:player/event/enter/attempt with storage summit.battlegrounds:temp profile
