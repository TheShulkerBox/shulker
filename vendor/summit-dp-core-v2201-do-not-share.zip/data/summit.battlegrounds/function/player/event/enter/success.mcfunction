# exit booth
advancement grant @s from summit:booth_exit_root
function #summit.booth:exit

# tag player
tag @s add summit.battlegrounds.player

# notify player
title @s actionbar ["", {text: "[Baobab Battlegrounds] ", color: "gold"}, {text: "You have entered the battlegrounds.", color: "green"}]

# save inventory and clear
function summit.inventory_management:save

# give kit
function summit.battlegrounds:player/action/give_kit

# function tag
function #summit.battlegrounds:api/player_enter
