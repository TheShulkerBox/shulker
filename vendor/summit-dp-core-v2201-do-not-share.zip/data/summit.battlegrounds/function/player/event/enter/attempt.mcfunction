

# get player kit
data remove storage summit.battlegrounds:temp player_kit
$data modify storage summit.battlegrounds:temp player_kit set from storage summit.battlegrounds:database kits[{player_id:$(id)}]

# function tag blocking
scoreboard players set #block_player_enter summit.battlegrounds 0
function #summit.battlegrounds:api/player_enter_attempt
execute unless score #block_player_enter summit.battlegrounds matches 0 run effect give @s invisibility 1 0 true
execute unless score #block_player_enter summit.battlegrounds matches 0 run return 0

# activate session if session is empty and player has kit
execute unless data storage summit.battlegrounds:database session if data storage summit.battlegrounds:temp player_kit run function summit.battlegrounds:player/event/enter/activate_session with storage summit.battlegrounds:temp player_kit

# let player know about activating battlegrounds
execute unless data storage summit.battlegrounds:database session unless data storage summit.battlegrounds:temp player_kit run title @s actionbar ["", {text: "[Baobab Battlegrounds] ", color: "gold"}, {text: "Select a kit from a nearby booth to begin playing!", color: "yellow"}]

# continue if session is active
execute if data storage summit.battlegrounds:database session run function summit.battlegrounds:player/event/enter/success
