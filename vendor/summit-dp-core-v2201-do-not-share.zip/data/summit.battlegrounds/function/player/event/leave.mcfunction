
# notify player
title @s actionbar ["", {text: "[Baobab Battlegrounds] ", color: "gold"}, {text: "You have left the battlegrounds.", color: "red"}]

# function tag
function #summit.battlegrounds:api/player_leave

# remove tag
tag @s remove summit.battlegrounds.player

# clear inventory and load
function summit.inventory_management:load
