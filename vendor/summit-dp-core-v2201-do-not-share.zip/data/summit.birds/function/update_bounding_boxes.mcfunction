execute as @e[tag=summit.bird_spawner] run function summit.birds:spawner/bounding_box
