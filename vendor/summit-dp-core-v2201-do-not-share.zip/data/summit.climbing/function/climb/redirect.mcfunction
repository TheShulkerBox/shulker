# up
execute if data entity @s {data: {tile_data: {direction: 0b}}} run return fail
# down
execute if data entity @s {data: {tile_data: {direction: 1b}}} run return fail
# south
execute if data entity @s {data: {tile_data: {direction: 2b}}} run rotate @s 0 0
# north
execute if data entity @s {data: {tile_data: {direction: 3b}}} run rotate @s 180 0
# east
execute if data entity @s {data: {tile_data: {direction: 4b}}} run rotate @s -90 0
# west
execute if data entity @s {data: {tile_data: {direction: 5b}}} run rotate @s 90 0

# set player seat pos
execute at @s rotated as @s run function summit.climbing:climb/player/change_seat_pos with entity @s data
