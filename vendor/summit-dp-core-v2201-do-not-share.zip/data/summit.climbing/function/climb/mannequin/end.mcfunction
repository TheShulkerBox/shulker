tp @s ~ ~ ~
tag @s add summit.climbing.end
#data modify entity @s pose set value "standing"