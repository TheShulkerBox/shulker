# check if summit.climbing player exists nearby
$execute if entity @a[distance=..32,tag=summit.climbing.player,nbt={UUID:$(UUID)}] run return 0

# if not, force kill every associated entity
function summit.climbing:climb/player/exit/force_end/kill with entity @s data
