# store entry in storage
data remove storage summit.climbing:master init.tile_data.entry
data modify storage summit.climbing:master init.tile_data.entry set from entity @s data.tile_data.entry

# check if path in that direction even exists
$execute unless data entity @s data.tile_data.$(direction).direct_0 unless data entity @s data.tile_data.$(direction).in unless data entity @s data.tile_data.$(direction).out run return 1

# set direction
$data modify storage summit.climbing:master init.move set value {direction:"$(direction)"}

# check type
$execute if data entity @s data.tile_data.$(direction).direct_0 run data modify storage summit.climbing:master init.move.type set value "direct_0"
$execute if data entity @s data.tile_data.$(direction).out run data modify storage summit.climbing:master init.move.type set value "out"
$execute if data entity @s data.tile_data.$(direction).in run data modify storage summit.climbing:master init.move.type set value "in"

# get movement coords
function summit.climbing:climb/move/single_space/set_movement_type with storage summit.climbing:master init.move

# redirect
function summit.climbing:climb/redirect

# spawn or move mannequin
execute if entity @s[tag=summit.climbing.initialized_climber] at @s run function summit.climbing:climb/mannequin/move/init with entity @s data
execute unless entity @s[tag=summit.climbing.initialized_climber] at @s run function summit.climbing:climb/mannequin/init

# if the climber enters an entry field with this tag, the summit.climbing sequence ends
tag @s add summit.climbing.initialized_climber

# if movement type is in or out, apply rotation to player
execute if data storage summit.climbing:master init.tile_data.entry run return 1
execute if data storage summit.climbing:master {init: {move: {direction: "right", type: "in"}}} as @p[tag=summit.climbing.current_main, distance=..32] run return run function summit.climbing:climb/player/rotate/set_target/relative/init {target: 90, operation: "add"}
execute if data storage summit.climbing:master {init: {move: {direction: "right", type: "out"}}} as @p[tag=summit.climbing.current_main, distance=..32] run return run function summit.climbing:climb/player/rotate/set_target/relative/init {target: 90, operation: "remove"}
execute if data storage summit.climbing:master {init: {move: {direction: "left", type: "in"}}} as @p[tag=summit.climbing.current_main, distance=..32] run return run function summit.climbing:climb/player/rotate/set_target/relative/init {target: 90, operation: "remove"}
execute if data storage summit.climbing:master {init: {move: {direction: "left", type: "out"}}} as @p[tag=summit.climbing.current_main, distance=..32] run return run function summit.climbing:climb/player/rotate/set_target/relative/init {target: 90, operation: "add"}
