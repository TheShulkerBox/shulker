
function summit.battlegrounds:api/assign_kit/v2 {booth_id: "blue_booth", kit_id: "blue_booth:kit_1", kit_function: "summit.battlegrounds.example:blue/give_kit_1", kit_name: "BLUE KIT"}
