# @s = as @n[ tag=aj.summit_flag.root, tag=!aj.new, distance=..1 ]
# align xyz positioned ~0.5 ~0.25 ~0.5
# run by summit:flag/control/spawn_flag

tag @s add summit_flag
data modify entity @s teleport_duration set value 10

scoreboard players set @s summit.flag.height 0
$scoreboard players set @s summit.flag.pole_height $(raise_height)

execute if data storage summit:temp summit_flag_macro{wind_sync: 1b} run tag @s add summit_flag.wind_sync
