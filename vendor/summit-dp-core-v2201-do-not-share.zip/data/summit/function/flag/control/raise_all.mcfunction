# @s = undefined
# at undefined
# run by player
# TODO: Call as a part of day cycle or flag changing cycle

execute as @e[type=item_display, tag=summit_flag] run function summit:flag/control/raise_this
