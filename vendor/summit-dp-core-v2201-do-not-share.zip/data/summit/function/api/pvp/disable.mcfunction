attribute @s minecraft:attack_damage modifier add summit:no_attack_damage -10000 add_value
