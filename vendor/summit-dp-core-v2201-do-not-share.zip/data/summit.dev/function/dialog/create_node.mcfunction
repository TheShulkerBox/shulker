# @s = player who used Node Creator
# at summit.nodeSpawner AEC
# run from summit.dev:entity/player/item/pig_egg

#// Check permission level
execute if entity @s[tag=summit.team.canCreateNode] run return run dialog show @s summit.dev:node/create_node

# Denied
tellraw @s {color: "red", text: "You aren't permitted to make nodes! Ask a Team Lead for assistance."}
kill @n[type=area_effect_cloud, tag=summit.nodeSpawner]

