schedule function summit.dev:server_startup/chunks_1 1
schedule function summit.dev:server_startup/chunks_2 2
schedule function summit.dev:server_startup/chunks_3 3
schedule function summit.dev:server_startup/chunks_4 4
schedule function summit.booth:entities/reset 10s
