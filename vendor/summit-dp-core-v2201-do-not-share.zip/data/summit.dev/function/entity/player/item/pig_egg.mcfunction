# @s = player with summit.dev.usedPigEgg matches 1..
# at undefined
# run from summit.dev:entity/player/tick

scoreboard players set @s summit.dev.usedPigEgg 0
execute if items entity @s weapon.mainhand minecraft:pig_spawn_egg[minecraft:custom_data={id: "node_creator"}] at @n[type=area_effect_cloud, tag=summit.nodeSpawner] run function summit.dev:dialog/create_node

