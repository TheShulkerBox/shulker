# @s = player
# at @s
# run from summit.dev:technical/tick

execute if score @s summit.dev.usedPigEgg matches 1.. run function summit.dev:item/pig_egg

