# @s = player
# at @s
# run from summit.dev:entity/node/global_list/display/format_list & self

$data modify storage summit:temp dev.globalList.formatted_list append value {label:"$(name) ($(claim))",width:300,action:{type:"minecraft:run_command",command:"dialog show @s {type:\"minecraft:multi_action\",title:\"Node Information\",body:[{type:\"minecraft:plain_message\",contents:{text:\"\ua000\",font:\"summit_technical:dialog\"}},{type:\"minecraft:plain_message\",contents:{text:\"Name:\",extra:[{text:\" $(name)\",underlined:0}],underlined:1}}, {type:\"minecraft:plain_message\",contents:{text:\"Created By:\",extra:[{text:\" $(owner)\",underlined:0}],underlined:1}}, {type:\"minecraft:plain_message\",contents:{text:\"Claimed By:\",extra:[{text:\" $(claim)\",underlined:0}],underlined:1}}, {type:\"minecraft:plain_message\",contents:{text:\"Description:\",underlined:1}}, {type:\"minecraft:plain_message\",contents:{text:\"$(description)\",underlined:0},width:400} ],inputs:[],after_action:\"close\",columns:1,exit_action:{label:\"Back\",action:{type:\"minecraft:show_dialog\",dialog:\"summit.dev:node/task_list\"}},actions:[{label:\"TP to Node\",width:100,tooltip:\"Teleport to this node.\",action:{type:\"minecraft:run_command\",command:\"/execute in $(dimension) run tp @s $(x) $(y) $(z)\"}}]}"}}














data remove storage summit:temp dev.globalList.displayNodes[-1]
execute if data storage summit:temp dev.globalList.displayNodes[-1] run function summit.dev:entity/node/global_list/display/format_tasks with storage summit:temp dev.globalList.displayNodes[-1]
