# @s = summit.node interaction
# at undefined
# run from summit.dev:technical/tick_2t

execute if data entity @s interaction run function summit.dev:entity/node/interact
