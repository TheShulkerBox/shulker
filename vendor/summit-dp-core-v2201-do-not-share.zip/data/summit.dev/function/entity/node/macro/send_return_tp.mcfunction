# @s = player via dialog
# at @s
# run from summit.dev:entity/node/macro/teleport_to_reference

$tellraw @s {"bold":true,"click_event":{"action":"run_command","command":"execute in $(dim) run tp @s $(x) $(y) $(z)"},"color":"aqua","text":"[Click to Return]"}
