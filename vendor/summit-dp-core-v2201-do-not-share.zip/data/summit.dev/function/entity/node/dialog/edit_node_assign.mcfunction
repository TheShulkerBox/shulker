# @s = player via dialog
# at @s
# run from summit.dev:entity/node/dialog/edit_node_pre

$dialog show @s {type:"minecraft:confirmation",title:"Assign Node",body:{type:"minecraft:plain_message",contents:"Write the name of the player to be assigned to this node.",width:250},inputs:[{type:"minecraft:text",key:"data",width:320,max_length:100,label:"Assign to",initial:"$(text)"}],can_close_with_escape:1,after_action:"close",yes:{label:"Assign Task",action:{type:"minecraft:dynamic/run_command",template:"function summit.dev:entity/node/dialog/edit_node_confirm {type:claim,id:\"$(id)\",data:\"$(data)\"}"}},no:{label:"Cancel"}}





