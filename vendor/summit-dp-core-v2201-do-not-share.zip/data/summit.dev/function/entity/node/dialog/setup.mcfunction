# @s = summit.node interaction with interaction data
# at undefined
# run from summit.dev:entity/node/interact

$data modify storage summit:temp dev.editNode.line.name set value "{type:\"minecraft:plain_message\",contents:{text:\"Name:\",extra:[{text:\" $(name)\",underlined:0}],underlined:1}}"
$data modify storage summit:temp dev.editNode.line.owner set value '{type:"minecraft:plain_message",contents:{text:"Created By:",extra:[{text:" $(owner)",underlined:0}],underlined:1}}'
$data modify storage summit:temp dev.editNode.line.claimer set value '{type:"minecraft:plain_message",contents:{text:"Claimed By:",extra:[{text:" $(claim)",underlined:0}],underlined:1}}'
$data modify storage summit:temp dev.editNode.line.desc set value "{type:\"minecraft:plain_message\",contents:{text:\"$(description)\",underlined:0},width:400}"

data modify storage summit:temp dev.editNode.data set from entity @s data

$execute if data storage summit:temp {dev:{editNode:{data:{claim:"Not Claimed"}}}} run data modify storage summit:temp dev.editNode.line.claim set value '{label:"Claim",width:150,tooltip:"Claim the task for this node.",action:{type:"minecraft:run_command",command:"function summit.dev:entity/node/dialog/claim_try {claim:\\\"$(claim)\\\",id:\\\"$(id)\\\",color:\\\"$(color)\\\"}"}}'
$execute unless data storage summit:temp {dev:{editNode:{data:{claim:"Not Claimed"}}}} run data modify storage summit:temp dev.editNode.line.claim set value '{label:"Unclaim",width:150,tooltip:"Clear the claim on this node.",action:{type:"minecraft:run_command",command:"function summit.dev:entity/node/dialog/unclaim_pre {owner:\\\"$(owner)\\\",claim:\\\"$(claim)\\\",id:\\\"$(id)\\\",color:\\\"$(color)\\\"}"}}'

execute if data storage summit:temp {dev: {editNode: {data: {ref: ""}}}} run data modify storage summit:temp dev.editNode.line.ref_tp set value '{label:"",tooltip:"This task has no reference coordinates",width:150}'
$execute unless data storage summit:temp {dev:{editNode:{data:{ref:""}}}} run data modify storage summit:temp dev.editNode.line.ref_tp set value '{label:"Teleport to Reference",tooltip:"Teleports you to the reference for this task.",width:150,action:{type:"minecraft:run_command",command:"function summit.dev:entity/node/macro/teleport_to_reference {ref:\\\"$(ref)\\\"}"}}'

$execute if data storage summit:temp {dev:{editNode:{data:{completed:true}}}} run data modify storage summit:temp dev.editNode.line.completed set value '{label:"Mark as Incomplete",width:150,tooltip:"Mark the task as incomplete.",action:{type:"minecraft:run_command",command:"function summit.dev:entity/node/dialog/incomplete_pre {owner:\\\"$(owner)\\\",claim:\\\"$(claim)\\\",id:\\\"$(id)\\\",color:\\\"$(color)\\\"}"}}'
$execute unless data storage summit:temp {dev:{editNode:{data:{completed:true}}}} run data modify storage summit:temp dev.editNode.line.completed set value '{label:"Mark as Complete",width:150,tooltip:"Mark the task as complete.",action:{type:"minecraft:run_command",command:"function summit.dev:entity/node/dialog/complete_pre {owner:\\\"$(owner)\\\",claim:\\\"$(claim)\\\",id:\\\"$(id)\\\",color:\\\"$(color)\\\"}"}}'

$data modify storage summit:temp dev.editNode.line.edit_name set value "{label:\"Edit Name\",width:150,tooltip:\"Edit the name of this node.\",action:{type:\"minecraft:run_command\",command:\"function summit.dev:entity/node/dialog/edit_node_pre {owner:\\\"$(owner)\\\",type:\\\"name\\\",id:\\\"$(id)\\\",text:\\\"$(name)\\\",color:\\\"$(color)\\\"}\"}}"

$data modify storage summit:temp dev.editNode.line.edit_desc set value "{label:\"Edit Description\",width:150,tooltip:\"Edit the description of this node.\",action:{type:\"minecraft:run_command\",command:\"function summit.dev:entity/node/dialog/edit_node_pre {owner:\\\"$(owner)\\\",type:\\\"description\\\",id:\\\"$(id)\\\",text:\\\"$(description)\\\",color:\\\"$(color)\\\"}\"}}"

$execute if data storage summit:temp {dev:{editNode:{data:{ref:""}}}} run data modify storage summit:temp dev.editNode.line.edit_ref set value '{label:"Add Reference",width:150,tooltip:"Add reference coords for this node.",action:{type:"minecraft:run_command",command:"function summit.dev:entity/node/dialog/edit_node_coords_pre {owner:\\\"$(owner)\\\",id:\\\"$(id)\\\",ref:\\\"execute in minecraft:overworld run tp @s 0.0 0.0 0.0\\\"}"}}'
$execute unless data storage summit:temp {dev:{editNode:{data:{ref:""}}}} run data modify storage summit:temp dev.editNode.line.edit_ref set value '{label:"Edit Reference Coords",tooltip:"Edit the coordinates for this task\\\'s reference.",width:150,action:{type:"minecraft:run_command",command:"function summit.dev:entity/node/dialog/edit_node_coords_pre {owner:\\\"$(owner)\\\",id:\\\"$(id)\\\",ref:\\\"$(ref)\\\"}"}}'

$data modify storage summit:temp dev.editNode.line.assign set value '{label:"Assign Node",width:150,tooltip:"Assign this node to someone.",action:{type:"minecraft:run_command",command:"function summit.dev:entity/node/dialog/edit_node_pre {owner:\\\"$(owner)\\\",type:\\\"assign\\\",id:\\\"$(id)\\\",text:\\\"$(owner)\\\",color:\\\"$(color)\\\"}"}}'

$data modify storage summit:temp dev.editNode.line.delete set value '{label:"Delete Node",width:150,tooltip:"Delete this node.",action:{type:"minecraft:run_command",command:"function summit.dev:entity/node/dialog/delete_try {name:$(owner),id:$(id)}"}}'

function summit.dev:entity/node/dialog/inspectmenu with storage summit:temp dev.editNode.line
