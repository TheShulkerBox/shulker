# @s = node owner or claimer who interacted with summit.node interaction
# at @s
# run from summit.dev:entity/node/dialog/complete_try

$data modify storage summit:temp dev.editNode.uuid set from storage summit:root dev.nodeList[{id:$(id)}].uuid
$data modify storage summit:temp dev.editNode.color set value "$(color)"

function summit.dev:entity/node/macro/edit_node_complete with storage summit:temp dev.editNode
data remove storage summit:temp dev.editNode
tag @s remove completingNode
